//Function to generate Input, with random numbers, non duplicate everytime
function generateInput(n){
  
  //setting an empty array of preferences
  let pref = []
  for (let m = 0; m < n; ++m){
    //setting another empty array of preferrences, that will be inside the previous preference array
    let prefIn = []
    
    //generating the incrementing values up to n and pushing it into the internal preference array
    for (let e = 0; e < n; ++e){
      prefIn.push(e);
    }
    
    //pushint the already created arrays of numbers 0 to n to be the indices of the "pref" array
    pref.push(prefIn)
  }

  //Implementing the fisher yates shuffle.
  for(let j = 0; j < pref.length; ++j){
      for(let k = 0; k < pref[j].length;++k){

        
        let len = pref[j].length
        //starting from the back of the array.
        while(--len > 0){

          //getting a random indices between 0 and len in order to access and element between the first and last element.
          let rndMiddle = Math.floor(Math.random() * (len+1));
          
          //swithing the current last element with an element situated between the first and the current last element.
          let temp = pref[k][rndMiddle]
          pref[k][rndMiddle] = pref[k][len];
          pref[k][len] = temp;
        }
      }
    }
    //returning a 2d array.
  return pref
  }

  //function to create multiple  tests for many variations of equal length arrays companies, candidates, and hires.
function oracle(f) {
  //the number of instances that is being tested
  let numTests = 5;
  for (let i = 0; i < numTests; ++i) {

    //length of the arrays
    let n = 10; 
    let companies = generateInput(n)
    let candidates = generateInput(n)
    let hires = f(companies, candidates);

    //Testing if the hires and companies have the same length
    test('Hires length is correct', function() {
      assert(companies.length === hires.length);
    });
    //Testing if there are duplicate numbers in all the arrays
    test('no duplicates for companies',function(){
      assert(companies.every(row => row.some(element => row.indexOf(element) === row.lastIndexOf(element))));
    });

    test('no duplicates for candidates', function(){
      assert(candidates.every(row => row.some(element => row.indexOf(element) === row.lastIndexOf(element))));
      });

    test('no duplicates for Hires', function(){
      assert(hires.some(element => hires.indexOf(element) === hires.lastIndexOf(element)));
      });
    //Testing the stability of the matching pairs.
    test('This is stable', function(){
      assert(stable());

      //Function to find the stable pair, where all criterias are satisfied
      function stable(){
        let isStable = true;
        for(let i=0; i<hires.length; ++i){
          for(let j=0; j<companies.length; ++j){

            //Current hire's company pointer
            let company = hires[i].company;
            
            //current hire's candidate pointer
            let candidate = hires[i].candidate;
            
            //Current highers potential company
            let potCompany = j;
            
            //companies potential candidate, not yet found
            let potCandidate = -1;

            //Finding the potential candidate
            for(let k=0; k < hires.length; ++k){
              if(hires[k].company === j){
                potCandidate = hires[k].candidate;
              }
            }
                
                //Storing the companies preference
                let comPref = companies[company];

                //Storing the candidates preference
                let canPref = candidates[potCandidate];

                
                if (comPref.indexOf(candidate) > comPref.indexOf(potCandidate) && canPref.indexOf(potCompany) > canPref.indexOf(company)){
                  isStable=false;
                }
              }
            }
            //returning wether it is stable
            return isStable;
          };
        });
        }
      }

oracle(wheat1);
oracle(chaff1);

