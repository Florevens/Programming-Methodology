//Function to generate Input, with random numbers, non duplicate everytime
function generateInput(n){
  
  //setting an empty array of preferences
  let pref = []
  for (let m = 0; m < n; ++m){
    //setting another empty array of preferrences, that will be inside the previous preference array
    let prefIn = []
    
    //generating the incrementing values up to n and pushing it into the internal preference array
    for (let e = 0; e < n; ++e){
      prefIn.push(e);
    }
    
    //pushint the already created arrays of numbers 0 to n to be the indices of the "pref" array
    pref.push(prefIn)
  }

  //Implementing the fisher yates shuffle.
  for(let j = 0; j < pref.length; ++j){
      for(let k = 0; k < pref[j].length;++k){

        
        let len = pref[j].length
        //starting from the back of the array.
        while(--len > 0){

          //getting a random indices between 0 and len in order to access and element between the first and last element.
          let rndMiddle = Math.floor(Math.random() * (len+1));
          
          //swithing the current last element with an element situated between the first and the current last element.
          let temp = pref[k][rndMiddle]
          pref[k][rndMiddle] = pref[k][len];
          pref[k][len] = temp;
        }
      }
    }
    //returning a 2d array.
  return pref
  }

  //function to create multiple  tests for many variations of equal length arrays companies, candidates, and hires.
function oracle(f) {
  //the number of instances that is being tested
  let numTests = 5;
  for (let i = 0; i < numTests; ++i) {

    //length of the arrays
    let n = 10; 
    let companies = generateInput(n)
    let candidates = generateInput(n)
    let hires = f(companies, candidates);

    //Testing if the hires and companies have the same length
    test('Hires length is correct', function() {
      assert(companies.length === hires.length);
    });
    //Testing if there are duplicate numbers in all the arrays
    test('no duplicates for companies',function(){
      assert(companies.every(row => row.some(element => row.indexOf(element) === row.lastIndexOf(element))));
    });

    test('no duplicates for candidates', function(){
      assert(candidates.every(row => row.some(element => row.indexOf(element) === row.lastIndexOf(element))));
      });

    test('no duplicates for Hires', function(){
      assert(hires.some(element => hires.indexOf(element) === hires.lastIndexOf(element)));
      });
    //Testing the stability of the matching pairs.
    test('This is stable', function(){
      assert(stable());

      //Function to find the stable pair, where all criterias are satisfied
      function stable(){
        let isStable = true;
        for(let i=0; i<hires.length; ++i){
          for(let j=0; j<companies.length; ++j){

            //Current hire's company pointer
            let company = hires[i].company;
            
            //current hire's candidate pointer
            let candidate = hires[i].candidate;
            
            //Current highers potential company
            let potCompany = j;
            
            //companies potential candidate, not yet found
            let potCandidate = -1;

            //Finding the potential candidate
            for(let k=0; k < hires.length; ++k){
              if(hires[k].company === j){
                potCandidate = hires[k].candidate;
              }
            }
                
                //Storing the companies preference
                let comPref = companies[company];

                //Storing the candidates preference
                let canPref = candidates[potCandidate];

                
                if (comPref.indexOf(candidate) > comPref.indexOf(potCandidate) && canPref.indexOf(potCompany) > canPref.indexOf(company)){
                  isStable=false;
                }
              }
            }
            //returning wether it is stable
            return isStable;
          };
        });
        }
      }

oracle(wheat1);
oracle(chaff1);










//Star of Part4b

function runOracle(f){
  //number of tests
  let numTests = 5;
  for (let i = 0; i < numTests; ++i) {
    let n = 10; // Change this to some reasonable size
    //generating random company and candidates for input

    let companies = generateInput(n);
    let candidates = generateInput(n);

    //generating the sequence of offers and hires.
    let run = f(companies, candidates);

    //storing the trace array, from company to candidate.
    let trace = run.trace;
    //storing the hire array, an array of valid matches with company and candidates
    //that is stable(of type run)
    let hire = run.out;
    
    //array to store the current matches
    let matches = []; 


    test('No duplicate proposals', function(){
      assert(checkDup(trace) === true);

      //Checks to see if there are no duplicate traces.
    function checkDup(trace){
      
      //instantiate arrays to push the offers that have happened so far onto
      let currentOffers = [];

      //iterate through the trace, and check Uniqueness
      for(let i = 0; i < trace.length; ++i){
        if(currentOffers.some(offer => (offer.fromCo === trace[i].fromCo && offer.from === trace[i].from && offer.to === trace[i].to))){
          return false;
        }
        //add the trace to the current offers if it is unique.
        currentOffers.push(trace[i]); 
      }
      return true;
    }
    });

    test('Offer sequence in the trace is valid', function() {
      assert(checkTrace(trace) === true);
      
      //Function to see if the offer sequence in the trace is valid, 
      //takes in trace which is an Offer array and returns a boolean
      //corresponding to validity.
      function checkTrace(trace){
      for(let i = 0; i < trace.length; ++i){
        //Checks to see if the offer is invalid, if it is, return false
        if(isMatched(trace[i],matches)){
          return false;
        } 
        if(priorityOffer(trace[i], i)){
          return false;
        }
        //if the offer is valid, add them to the list of matches
        if(isUnmatched(trace[i])){
          matches.push(matchGenerator(trace[i]));
        } 
        //if there is a better valid offer, push it to matches
        else if(bestMatch(trace[i])){
          matches = matches.filter(e => (trace[i].fromCo ? (e.candidate !== trace[i].to) 
          : (e.company !== trace[i].to)));
          matches.push(matchGenerator(trace[i]));
        }
      }
      return true;
    }
    });

    test('Is the resulf of the offers in the trace', function(){
      assert(checkMatches(matches) === true);

    function checkMatches(matches){
      //checks if hire and matches size match, 
      //if not, then "hire" of out and hire of matches differ
      if(hire.length !== matches.length){
        return false;
      }
      //iterate through the hire objects
      for(let i = 0; i < hire.length; ++i){

        //Storing the company and candidate of hire
        let comHire = hire[i].company;
        let canHire = hire[i].candidate;

        let compIndex = matches.findIndex(e => e.company === comHire);

        //Checks to see if the company is in matches
        if(compIndex !== -1 && matches[compIndex].candidate !== canHire){
          return false;
        }
      }
      return true;
    }


    });

    //creates a match for an offer
    function matchGenerator(offer){
      //if the match is from a company, company = offer.from and
      //candidate = offer.to
      if(offer.fromCo){
        return ({company: offer.from, candidate: offer.to});
      }
      //if it is from a candidate, then it is to a company
      return ({company: offer.to, candidate: offer.from});
    }

    //checks if recieving party is unmatched
    function isUnmatched(offer){
      if(offer.fromCo){
        //if the offer is from a company, and any candidate in matches is
        //not the same candidate that is in the offer, return true.
        return matches.some(e => e.candidate === offer.to) === false;
      }
      //if the offer is from a candidate, and any company in matches is not
      //the same company that is in the offer, it is unmatched and rturn true
      return matches.some(i => i.company === offer.to) === false;
    }

    
    //constructs array of previous offers sent by offering party, returns false if not offering to 
    //next party on priority list
    function priorityOffer(offer, index){
      let madeOffers = [];

      //If the match has already made, add it to the list of previous offers
      for(let i = 0; i < index; ++i){
        if(trace[i].fromCo === offer.fromCo && trace[i].from === offer.from){
          madeOffers.push(trace[i]);
        }
      }
      //if this is the first offer, meaning there are no previous offers,
      //add it to the top of priority offer list.
      if(madeOffers.length === 0){
        if(offer.fromCo){
          return companies[offer.from][0] !== offer.to;
        }
        else{
          return candidates[offer.from][0] !== offer.to;
        }
      }
      //if the index following the last offer on priority list equals the offer, returns false
      let finalOf = madeOffers[madeOffers.length - 1];

      if(finalOf.fromCo){
        //the candidate = to the lastOffers candidate
        let candidate = finalOf.to;
        //the company = lasOffers company
        let company = finalOf.from;

        let madeIndex = companies[company].indexOf(candidate);
        return companies[company][madeIndex+1] !== offer.to;
      }
      else{
        //it is from a candidate
        let candidate = finalOf.from;
        //it is to a company
        let company = finalOf.to;

        let madeIndex = candidates[candidate].indexOf(company);
        return candidates[candidate][madeIndex+1] !== offer.to;
      }
    }

    
    //Checks to see if the offering party already has a match
    //returns true if that is the case.
    function isMatched(offer, matches){

      //If the offer is from a company, checks to see if that company is already taken
      //and matched 
      if(offer.fromCo){
        return matches.some(e => e.company === offer.from);
      }
      //if the offer is from a candidate, checks to see if the candidate is already taken
      //and matched.
      return matches.some(e => e.candidate === offer.from);
    }
    //Checks to see if the current offer is a better match than the current match
    function bestMatch(offer){
      //if the offer is from a company, candidate is what the offer is to
      //and where the offer is from is set to company
      if(offer.fromCo){
        let candidate = offer.to;
        let company = offer.from;

        //if the offer is from a company
        //Finds the first candidate in matches that equals
        //to the current candidate and set it as the potential match.
        let potMatch = matches.find(e => e.candidate === candidate);
        return candidates[candidate].indexOf(company) 
        < candidates[candidate].indexOf(potMatch.company);
      }
      else{
        //otherwise the offer is from a candidate to a company
        let candidate = offer.from;
        let company = offer.to;
        //Finds the first company in matches that equals
        //to the current candidate and make it to the potential match
        let potMatch = matches.find(e => e.company === company);
        return companies[company].indexOf(candidate) 
        < companies[company].indexOf(potMatch.candidate);
      }
    }
  }
}

const oracleLib = require('oracle');
runOracle(oracleLib.traceWheat1);

