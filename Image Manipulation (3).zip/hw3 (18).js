let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

//Function for 3p
function lineBlur3p(image, lineNum){
  let image2 = image.copy();
  for(let i = 0; i < image2.width; ++i){
    for(let j = 0; j < image2.height; ++j){
      //Checking middle pixel
      if (j === lineNum && i < image2.width - 1 && i > 0){
        let left = image2.getPixel(i-1, j);
        let middle = image2.getPixel(i,j);
        let right = image2.getPixel(i+1, j);
        
        let newRed = 1/3*left[0] + 1/3*middle[0] + 1/3*right[0]
        let newBlue = 1/3*left[1] + 1/3*middle[1] + 1/3*right[1]
        let newGreen = 1/3*left[2] + 1/3*middle[2] + 1/3*right[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen])
      }
      //2 pixels, left border 
      else if(j === lineNum && i === 0 && image2.width >= 2){
        let middle = image2.getPixel(i, j);
        let right = image2.getPixel(i+1, j);

        let newRed = 2/3*middle[0] + 1/3*right[0]
        let newBlue = 2/3*middle[1] + 1/3*right[1]
        let newGreen = 2/3*middle[2] + 1/3*right[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
      //2 Pixels, right border
      else if(j === lineNum && i < image2.width - 1 && i > 0 ){
        let left = image2.getPixel(i-1, j);
        let middle = image2.getPixel(i, j);

        let newRed = 1/3*left[0] + 2/3*middle[0]
        let newBlue = 1/3*left[1] + 2/3*middle[1]
        let newGreen = 1/3*left[2] + 2/3*middle[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     else{}
    }
  }
}
//Function for distance of 2...
function lineBlur5p(image, lineNum){
  let image3 = image.copy();
  for(let i = 0; i < image3.width; ++i){
    for(let j = 0; j < image3.height; ++j){
      //Checking middle Pixel
      if(j === lineNum && i >= 2 && i <= image3.width - 3 && image3.width >=5){
        let left1 = image3.getPixel(i-1, j);
        let left2 = image3.getPixel(i-2,j);
        let middle = image3.getPixel(i, j);
        let right1 = image3.getPixel(i+1, j);
        let right2 = image3.getPixel(i+2, j);

        let newRed = 1/5*left1[0] + 1/5*left2[0] + 1/5*middle[0] + 1/5*right1[0] + 1/5*right2[0]
        let newBlue = 1/5*left1[1] + 1/5*left2[1] + 1/5*middle[1] + 1/5*right1[1] + 1/5*right2[1]
        let newGreen = 1/5*left1[2] + 1/5*left2[2] + 1/5*middle[2] + 1/5*right1[2] + 1/5*right2[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen] )
      }
      //Checking leftmost Pixel, cud be combined
      else if(j === lineNum && i === 0 && image3.width >= 3){
        let middle  = image3.getPixel(i, j);
        let right1= image3.getPixel(i+1, j);
        let right2 = image3.getPixel(i+2, j);

        let newRed = 3/5*middle[0] + 1/5*right1[0] + 1/5*right2[0]
        let newBlue = 3/5*middle[1] + 1/5*right1[1] + 1/5*right2[1]
        let newGreen = 3/5*middle[2] + 1/5*right1[2] + 1/5*right2[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen])
      }
      //Checking rightmost Pixel, cud be combined
      else if(j === lineNum && i === image3.width - 1){
        let left2 = image3.getPixel(i-2, j);
        let left1 = image3.getPixel(i-1, j);
        let middle = image3.getPixel(i, j);

        let newRed = 3/5*middle[0] + 1/5*left1[0] + 1/5*left2[0]
        let newBlue = 3/5*middle[1] + 1/5*left1[1] + 1/5*left2[1]
        let newGreen = 3/5*middle[2] + 1/5*left1[2] + 1/5*left2[2]
        image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking 4 pixels, with two pixels to the right and 1 to the left
     else if(j === lineNum && i === 1 && image3.width >= 4){
       let left = image3.getPixel(i-1, j);
       let middle = image3.getPixel(i, j);
       let right1 = image3.getPixel(i+1, j)
       let right2 = image3.getPixel(i+2, j)

       let newRed = 2/5*middle[0] + 1/5*left[0] + 1/5*right1[0] + 1/5*right2[0]
       let newBlue = 2/5*middle[1] + 1/5*left[1] + 1/5*right1[1] + 1/5*right2[1]
       let newGreen = 2/5*middle[2] + 1/5*left[2] + 1/5*right1[2] + 1/5*right2[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking 4 Pixels, with two to the left and 1 to the right
     else if(j === lineNum && i === image3.width-2 && image3.width >= 4){
       let right1 = image3.getPixel(i+1, j);
       let middle = image3.getPixel(i, j);
       let left1 = image3.getPixel(i-1, j)
       let left2 = image3.getPixel(i-2, j)

       let newRed = 2/5*middle[0] + 1/5*right1[0] + 1/5*left1[0] + 1/5*left2[0]
       let newBlue = 2/5*middle[1] + 1/5*right1[1] + 1/5*left1[1] + 1/5*left2[1]
       let newGreen = 2/5*middle[2] + 1/5*right1[2] + 1/5*left1[2] + 1/5*left2[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking for 3 pixels, with the target being leftmost
     else if(j === lineNum && i === 0){
       let middle = image3.getPixel(i, j);
       let right1 = image3.getPixel(i+1, j);
       let right2 = image3.getPixel(i+2, j);

       let newRed = 3/5*middle[0] + 1/5*right1[0] + 1/5*right2[0]
       let newBlue = 3/5*middle[1] + 1/5*right1[1] + 1/5*right2[1]
       let newGreen = 3/5*middle[2] + 1/5*right1[2] + 1/5*right2[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking for 3 pixels with the target being rightmost
     else if(j === lineNum && i === image3.width-1 && image3.width >= 3){
       let middle = image3.getPixel(i, j);
       let left1 = image3.getPixel(i-1, j);
       let left2 = image3.getPixel(i-2, j);
       
       let newRed = 3/5*middle[0] + 1/5*left1[0] + 1/5*left2[0]
       let newBlue = 3/5*middle[1] + 1/5*left1[1] + 1/5*left2[1]
       let newGreen = 3/5*middle[2] + 1/5*left1[2] + 1/5*left2[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking 3 Pixels witht the target being in the middle
     else if(j === lineNum && i === 1 && i === image3.width === 3){
       let left = image3.getPixel(i-1, j);
       let middle = image3.getPixel(i,j);
       let right = image3.getPixel(i+1, j);
       
       let newRed = 1/5*left[0] + 3/5*middle[0] + 1/5*right[0]
       let newBlue = 1/5*left[1] + 3/5*middle[1] + 1/5*right[1]
       let newGreen = 1/5*left[2] + 3/5*middle[2] + 1/5*right[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen])
     }
     //Checking only a 2 pixel image, target on left border
     else if(j === lineNum && i === 0 && image3.width === 2){
       let middle = newImage.getPixel(i, j);
       let right = newImage.getPixel(i+1, j);

       let newRed = 4/5*middle[0] + 1/5*right[0]
       let newBlue = 4/5*middle[1] + 1/5*right[1]
       let newGreen = 4/5*middle[2] + 1/5*right[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     //Checking only a 2 pixel image, target on right border
     else if(j === lineNum && i === image3.width - 1 && i !== 0 && i === 2){
       let left = newImage.getPixel(i-1, j);
       let middle = newImage.getPixel(i, j);
       
       let newRed = 1/5*left[0] + 4/5*middle*p1[0]
       let newBlue = 1/5*left[1] + 4/5*middle*p1[1]
       let newGreen = 1/5*left[2] + 4/5*middle*p1[2]
       image.setPixel(i, j, [newRed, newBlue, newGreen] )
     }
     else{}
    }
  }
}

function blurLines(image, func){
 let image4 = image.copy()
   for(let i = 0; i < image4.width; ++i){
     function blurLine(image4, i){
     }
   }
   return image4;
 }
 
 

function pixelBlur(image,x,y){
  if(x<0 || y<0){
    return;
  }
  let blurredPix = image.getPixel(x,y);
 
  let topPix = findNeighbours(image,x,y-1);
  let botPix = findNeighbours(image,x,y+1);
  let leftPix= findNeighbours(image,x-1,y);
  let rightPix = findNeighbours(image,x+1,y);

  let topRight = findNeighbours(image,x+1,y+1);
  let bottomLeft = findNeighbours(image,x-1,y-1);
  let bottomRight = findNeighbours(image,x+1,y-1);
  let topLeft = findNeighbours(image,x-1,y+1);
 
  let neighbours = [topPix, botPix, leftPix, rightPix, topLeft, bottomRight,bottomLeft,topRight];
  let num = 9;
  let count = 0;
  neighbours.forEach( p=> {
  if(pixelEq(p, [0,0,0])){  
    ++count;
  }
});
num = num - count;
 
 for(let i=0; i<3; ++i){
   blurredPix[i] = (blurredPix[i] + botPix[i] + topPix[i] + leftPix[i] + rightPix[i] + topLeft[i] + bottomRight[i] + bottomLeft[i] + topRight[i])/num;
  }
  return blurredPix;
}

 
  //PixelBlurr helper
  function findNeighbours(image, x, y){
   if(x < 0 || y < 0 || x>image.width -1 || y> image.height -1){
     return [0,0,0];
   }
   return image.getPixel(x,y);
   }

 
 function imageMap(image, func){
   let image5 = image.copy();
   for( let i = 0; i < image5.width; ++i){
     for( let j = 0; j < image5.height; ++j){
       image5.setPixel(i, j, func(image, i, j));
     }
   }
   return image5;
 }


 
 
 function imageBlur(image){
   return imageMap(image, pixelBlur)
 }

 function composeFunctions(fa){
   return function(pixel){
     return fa.reduce((val, f) => f(val), pixel);
    }
  }

 function removeRed(robot){
 let image6 = robot;
 for(let i = 0; i < image6.width; ++i){
   for(let j = 0; j < image6.height; ++j){
    let color = image6.getPixel(i, j);
     image6.setPixel(i, j, [0.0, color[1] , color[2]]);
   }
 }
 return image6;
}


function flipColors(robot){
   let image7 = robot;
   for(let i = 0; i < image7.width; ++i){
     for(let j = 0; j < image7.height; ++j){
       let formerColor = image7.getPixel(i, j);
       image7.setPixel(i, j, [ (formerColor[1] + formerColor[2])/2, (formerColor[0] + formerColor[2])/2, (formerColor[0] + formerColor[1])/2 ])
     }
   }
     return image7;
 }
 function combineThree(image){
 let image1 = removeRed(image);
 let image2 = flipColors(image1);
 let image3 = flipColors(image2);
 return image3;
 }
 

 
 
 
