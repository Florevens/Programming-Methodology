let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

function imageMapCoord(img, func){
  let newImg = img.copy();
  for(let i = 0; i < newImg.width; ++i){
    for(let j = 0; j < newImg.height; ++j){
      newImg.setPixel(i,j,func(img,i,j));
    }
  }
  return newImg
}
function imageMapIf(img, cond, func){
 return imageMapCoord(img, function(img, x, y){
   if(cond(img, x, y)){ 
     return func(img.getPixel(x,y)); 
    }
     else{  
       return img.getPixel(x, y) 
      }
 })
 
}

function mapWindow(img,xmin,ymin,xmax, ymax,func){
  return imageMapIf(img, function cond(img, x, y){
   if((x >= xmin && x <= xmax) && (y >= ymin && y <= ymax)){
     return true;
    }
     else{ 
       return false; 
      }
     }, func);
  
}
function makeBorder(img, thickness, func){
  let newImage2 = img.copy()
  return imageMapIf(newImage2,function cond(newImage2,x2,y2){
    if(img.width - x2-1 < thickness || img.height - y2-1 < thickness || x2 < thickness || y2 < thickness){
      return true
    }
    else{
      return false
    }
  }, func)
  }
  
    
  function dimCenter(img, thickness){
    let newImage3 = img.copy()
    return imageMapIf(newImage3, function cond(newImage3,x2,y2){
      if(!(img.width - x2-1 < thickness || img.height - y2-1 < thickness || x2 < thickness || y2 < thickness)){
        return true
      }
      else{
        return false
      }
    },A => ( [A[0]*0.8, A[1]*0.8, A[2]*0.8 ]))
    }
  
  function redBorder(img, thickness){
    return imageMapIf(img, function cond(img, x2, y2){
      if(img.width - x2-1 < thickness || img.height - y2-1 < thickness || x2 < thickness || y2 < thickness){
        return true
      }
      else{
        return false
      }
    }, A => ( [ A[0] = 1, A[1] = 0, A[2]=0 ] ))
    }


  function grayBorder(img, thickness){
    let newImage4 = img.copy()
    return makeBorder (img, thickness, function(pixel){
     let mean = (pixel[0] + pixel[1] + pixel[2])/3;
     return [mean, mean, mean];
   })
 }
 
redBorder(robot, 10).show();
dimCenter(robot, 20).show();
grayBorder(robot,50).show();

    

    
    



    

    
      
      
    
    
    
 


  











