let robot =
lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

robot.show();

function removeRed(robot){
  for(let i = 0; i < robot.width; ++i){
    for(let j = 0; j < robot.height; ++j){
      let origPixel = robot.getPixel(i,j);
      robot.setPixel(i,j,[0, origPixel[1], origPixel[2]]);
    }
  } 
  return robot
}
removeRed(robot)
robot.show()


function flipColors(robot){
  let newImg = robot
  for(let i = 0; i < newImg.width; ++i){
    for(let j = 0; j < newImg.height; ++j){
      let origPixel = newImg.getPixel(i,j);
      newImg.setPixel(i,j,
      [
      (origPixel[1]+origPixel[2])/2,
      (origPixel[0]+origPixel[2])/2,
      (origPixel[0]+origPixel[1])/2
      ]
      )
    }
  }
  return newImg
}
flipColors(robot)
robot.show()

function mapLine(image, lineNum, func){
  if( lineNum > image.height || lineNum <= 0){
    return;
  }
  else{
    for(let i = 0; i < image.width; ++i){
      let currPixel = image.getPixel(i, lineNum)
      image.setPixel(i, lineNum, func(currPixel))
    }
  }
}

function imageMap(image, func){
  let newImage = image.copy()
  for(let lineNum = 0; lineNum < image.height; ++lineNum){
    mapLine(newImage, lineNum, func)
  }
  return newImage
}

function mapToGB(robot){
  return imageMap(robot, A => ( [0.0, A[1], A[2] ] ) );
}

function mapFlipColors(robot){
   return imageMap(robot, flipColor =>([(flipColor[1] + flipColor[2])/2,(flipColor[0] + flipColor[2])/2,(flipColor[0]+flipColor[1])/2]));
 }


 test('removeRed function definition is correct', function() {
const white = lib220.createImage(10, 10, [1,1,1]);
removeRed(white).getPixel(0,0);
// Checks that code runs. Need to use assert to check properties.
});

test('No red in removeRed result', function() {
// Create a test image, of size 10 pixels x 10 pixels, and set it to all white.
const white = lib220.createImage(10, 10, [1,1,1]);
// Get the result of the function.
const shouldBeBG = removeRed(white);
// Read the center pixel.
const pixelValue = shouldBeBG.getPixel(5, 5);
// The red channel should be 0.
assert(pixelValue[0] === 0);
// The green channel should be unchanged.
assert(pixelValue[1] === 1);
// The blue channel should be unchanged.
assert(pixelValue[2] === 1);
});

function pixelEq (p1, p2) {
const epsilon = 0.002;
for (let i = 0; i < 3; ++i) {
if (Math.abs(p1[i] - p2[i]) > epsilon) {
return false;
}
}
return true;
};
test('Check pixel equality', function() {
const inputPixel = [0.5, 0.5, 0.5]
// Create a test image, of size 10 pixels x 10 pixels, and set it to the inputPixel
const image = lib220.createImage(10, 10, inputPixel);
// Process the image.
const outputImage = removeRed(image);
// Check the center pixel.
const centerPixel = outputImage.getPixel(5, 5);
assert(pixelEq(centerPixel, [0, 0.5, 0.5]));
// Check the top-left corner pixel.
const cornerPixel = outputImage.getPixel(0, 0);
assert(pixelEq(cornerPixel, [0, 0.5, 0.5]));
});











